from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import Response, StreamingResponse
import json
from fastapi.middleware.cors import CORSMiddleware
from .repository import repository
from .schemas import HealthResponse, Resume, ResumeCreate
from .services.ollama import ollama_provider
from .services.ai import context, generate
from .services.analysis import analyze_job_match, ats_analysis
from .services.documents import draft_from_text, extract_text, resume_pdf
from .config import settings

app = FastAPI(title="AI Resume Writer", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_methods=["*"], allow_headers=["*"])


@app.get("/api/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    return HealthResponse(status="ok", ai=await ollama_provider.status())


@app.post("/api/resumes", response_model=Resume, status_code=201)
def create_resume(payload: ResumeCreate) -> Resume:
    return repository.create(payload)


@app.get("/api/resumes/{resume_id}", response_model=Resume)
def get_resume(resume_id: str) -> Resume:
    resume = repository.get(resume_id)
    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")
    return resume


@app.put("/api/resumes/{resume_id}", response_model=Resume)
def update_resume(resume_id: str, payload: ResumeCreate) -> Resume:
    resume = repository.update(resume_id, payload)
    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")
    return resume


@app.post("/api/ai/summary")
async def summary(payload: dict):
    content = ResumeCreate(**{"content": payload.get("content", {})}).content
    prompt = context(content) + "\n\nWrite a 2-3 sentence professional summary using supplied facts only."
    return {"suggestion": await generate(prompt), "review_required": True}


@app.post("/api/ai/rewrite-bullet")
async def rewrite_bullet(payload: dict):
    content = ResumeCreate(**{"content": payload.get("content", {})}).content
    bullet = str(payload.get("bullet", ""))
    if not bullet.strip(): raise HTTPException(status_code=422, detail="Provide a bullet to rewrite.")
    prompt = context(content) + f"\n\nRewrite this bullet with action, task, technology and result only when evidenced: {bullet}"
    return {"suggestion": await generate(prompt), "review_required": True}


@app.post("/api/ai/tailor")
async def tailor(payload: dict):
    content = ResumeCreate(**{"content": payload.get("content", {})}).content
    return analyze_job_match(content, str(payload.get("job_description", "")))


@app.post("/api/ai/analyze")
async def analyze(payload: dict):
    content = ResumeCreate(**{"content": payload.get("content", {})}).content
    return ats_analysis(content, str(payload.get("job_description", "")))


@app.post("/api/chat")
async def chat(payload: dict):
    content = ResumeCreate(**{"content": payload.get("content", {})}).content
    message = str(payload.get("message", ""))
    if not message.strip(): raise HTTPException(status_code=422, detail="Enter a message.")
    reply = await generate(context(content, str(payload.get("job_description", ""))) + f"\n\nUSER REQUEST: {message}")
    return {"reply": reply, "review_required": True}


@app.post("/api/chat/stream")
async def chat_stream(payload: dict) -> StreamingResponse:
    """SSE-compatible chat response for clients that want incremental rendering."""
    content = ResumeCreate(**{"content": payload.get("content", {})}).content
    message = str(payload.get("message", ""))
    if not message.strip():
        raise HTTPException(status_code=422, detail="Enter a message.")
    reply = await generate(context(content, str(payload.get("job_description", ""))) + f"\n\nUSER REQUEST: {message}")

    async def events():
        for token in reply.split(" "):
            yield f"data: {json.dumps({'token': token + ' '})}\n\n"
        yield "data: [DONE]\n\n"
    return StreamingResponse(events(), media_type="text/event-stream")


@app.post("/api/import")
async def import_resume(file: UploadFile = File(...)):
    return draft_from_text(await extract_text(file, settings.max_upload_mb * 1024 * 1024))


@app.get("/api/export/{resume_id}/pdf")
def export_pdf(resume_id: str) -> Response:
    resume = repository.get(resume_id)
    if not resume: raise HTTPException(status_code=404, detail="Resume not found")
    return Response(resume_pdf(resume), media_type="application/pdf", headers={"Content-Disposition": f'attachment; filename="{resume.title or "resume"}.pdf"'})
