import json
from fastapi import HTTPException
from .ollama import ollama_provider
from ..config import settings
from ..schemas import ResumeContent

SYSTEM_RULES = """You are a careful resume writing assistant. Use only facts in the provided resume context.
Never invent employers, dates, degrees, metrics, technologies, certifications, or achievements. If a fact is missing, ask for it.
Be concise and return plain text unless JSON is explicitly requested."""


async def generate(prompt: str) -> str:
    status = await ollama_provider.status()
    if not status.available:
        raise HTTPException(status_code=503, detail=status.detail)
    import httpx
    body = {"model": settings.ollama_model, "prompt": prompt, "stream": False, "options": {"temperature": 0.2}}
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            response = await client.post(f"{settings.ollama_base_url}/api/generate", json=body)
            response.raise_for_status()
        return str(response.json().get("response", "")).strip()
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=503, detail="Ollama could not generate a response. Check its model and service status.") from exc


def context(content: ResumeContent, job_description: str = "") -> str:
    value = json.dumps(content.model_dump(mode="json"), ensure_ascii=False)
    return f"{SYSTEM_RULES}\n\nRESUME FACTS:\n{value}\n\nJOB DESCRIPTION:\n{job_description[:8000]}"
