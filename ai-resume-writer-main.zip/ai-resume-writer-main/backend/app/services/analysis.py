import re
from collections import Counter
from dataclasses import dataclass
from ..schemas import ResumeContent

STOP_WORDS = {"a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "in", "is", "of", "on", "or", "the", "to", "with", "you", "your", "will", "our", "we", "this", "that", "have", "has", "years", "work", "role", "team", "experience"}
ACTION_VERBS = {"built", "created", "delivered", "designed", "developed", "drove", "improved", "increased", "launched", "led", "managed", "optimized", "reduced", "shipped", "supported", "implemented", "automated", "analyzed"}


def resume_text(content: ResumeContent) -> str:
    values = [content.summary, *content.skills, *content.certifications, *content.achievements]
    for item in content.experience:
        values.extend([item.company, item.role, *item.bullets, *item.technologies])
    for item in content.projects:
        values.extend([item.name, item.description, *item.bullets, *item.technologies])
    return " ".join(values).lower()


def keywords(text: str, limit: int = 25) -> list[str]:
    tokens = re.findall(r"[A-Za-z][A-Za-z0-9+#.\-]{1,}", text.lower())
    counts = Counter(token for token in tokens if token not in STOP_WORDS and len(token) > 1)
    return [word for word, _ in counts.most_common(limit)]


def analyze_job_match(content: ResumeContent, job_description: str) -> dict:
    wanted = keywords(job_description)
    corpus = resume_text(content)
    matched = [term for term in wanted if term in corpus]
    missing = [term for term in wanted if term not in corpus]
    coverage = round(100 * len(matched) / max(len(wanted), 1))
    return {"keywords": wanted, "matched_keywords": matched, "missing_keywords": missing,
            "coverage": coverage,
            "suggestions": ([f"Only add '{term}' if it reflects work you actually performed." for term in missing[:4]])}


def ats_analysis(content: ResumeContent, job_description: str = "") -> dict:
    issues: list[dict[str, str]] = []
    contact = content.contact
    if not contact.name or contact.name == "Your Name":
        issues.append({"category": "Completeness", "message": "Add your full name."})
    if not contact.email:
        issues.append({"category": "Completeness", "message": "Add a professional email address."})
    if not content.summary:
        issues.append({"category": "Structure", "message": "Add a concise, fact-based professional summary."})
    if not content.skills:
        issues.append({"category": "Keywords", "message": "List relevant technical and professional skills."})
    bullets = [bullet for item in content.experience for bullet in item.bullets]
    long_bullets = [bullet for bullet in bullets if len(bullet.split()) > 35]
    weak_bullets = [bullet for bullet in bullets if bullet and bullet.split()[0].lower().strip(".,") not in ACTION_VERBS]
    if long_bullets:
        issues.append({"category": "Readability", "message": "Shorten bullets over 35 words for faster scanning."})
    if weak_bullets:
        issues.append({"category": "Impact", "message": "Start experience bullets with a clear action verb where accurate."})
    structure = max(0, 100 - sum(issue["category"] in {"Structure", "Completeness"} for issue in issues) * 15)
    readability = max(0, 100 - len(long_bullets) * 12)
    impact = max(0, 100 - len(weak_bullets) * 7)
    keyword_score = analyze_job_match(content, job_description)["coverage"] if job_description else (80 if content.skills else 35)
    breakdown = {"structure": structure, "keyword_coverage": keyword_score, "readability": readability, "impact": impact}
    score = round(sum(breakdown.values()) / len(breakdown))
    return {"score": score, "breakdown": breakdown, "issues": issues,
            "disclaimer": "This is a transparent heuristic, not a guarantee of ATS acceptance or an interview."}
