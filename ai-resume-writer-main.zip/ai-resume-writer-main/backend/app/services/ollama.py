import httpx
from ..config import settings
from ..schemas import ProviderStatus


class OllamaProvider:
    """Local-only Ollama adapter. No hosted fallback is used."""
    async def status(self) -> ProviderStatus:
        try:
            async with httpx.AsyncClient(timeout=2.0) as client:
                response = await client.get(f"{settings.ollama_base_url}/api/tags")
                response.raise_for_status()
            return ProviderStatus(provider="ollama", available=True, model=settings.ollama_model,
                                  detail="Local Ollama is ready")
        except httpx.HTTPError:
            return ProviderStatus(provider="ollama", available=False, model=settings.ollama_model,
                                  detail="Start Ollama and run the configured model to enable AI features.")


ollama_provider = OllamaProvider()
