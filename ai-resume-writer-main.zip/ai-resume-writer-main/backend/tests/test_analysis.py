from app.schemas import Contact, Experience, ResumeContent
from app.services.analysis import analyze_job_match, ats_analysis


def sample_content() -> ResumeContent:
    return ResumeContent(contact=Contact(name="Sam Lee", email="sam@example.com"), skills=["Python", "FastAPI"],
        summary="Backend developer.", experience=[Experience(id="1", company="Acme", role="Developer", bullets=["Built FastAPI services for customers."])])


def test_job_match_identifies_present_and_absent_keywords():
    result = analyze_job_match(sample_content(), "Seeking a Python FastAPI developer with Docker skills.")
    assert "python" in result["matched_keywords"]
    assert "docker" in result["missing_keywords"]


def test_ats_analysis_returns_transparent_breakdown():
    result = ats_analysis(sample_content())
    assert result["score"] > 0
    assert set(result["breakdown"]) == {"structure", "keyword_coverage", "readability", "impact"}
