import type { Resume, ResumeContent } from './types'
const BASE = import.meta.env.VITE_API_URL ?? 'http://localhost:8000/api'
async function request<T>(path: string, init?: RequestInit): Promise<T> { const res = await fetch(`${BASE}${path}`, { headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) }, ...init }); if (!res.ok) { const data = await res.json().catch(() => ({})); throw new Error(data.detail ?? 'Request failed') } return res.json() }
export const api = {
  create: (resume: Resume) => request<Resume>('/resumes', { method: 'POST', body: JSON.stringify(resume) }),
  update: (id: string, resume: Resume) => request<Resume>(`/resumes/${id}`, { method: 'PUT', body: JSON.stringify(resume) }),
  analyze: (content: ResumeContent, job_description: string) => request<Analysis>('/ai/analyze', { method: 'POST', body: JSON.stringify({ content, job_description }) }),
  tailor: (content: ResumeContent, job_description: string) => request<Match>('/ai/tailor', { method: 'POST', body: JSON.stringify({ content, job_description }) }),
  summary: (content: ResumeContent) => request<{ suggestion: string }>('/ai/summary', { method: 'POST', body: JSON.stringify({ content }) }),
  rewrite: (content: ResumeContent, bullet: string) => request<{ suggestion: string }>('/ai/rewrite-bullet', { method: 'POST', body: JSON.stringify({ content, bullet }) }),
  chat: (content: ResumeContent, message: string, job_description: string) => request<{ reply: string }>('/chat', { method: 'POST', body: JSON.stringify({ content, message, job_description }) })
}
export type Analysis = { score: number; breakdown: Record<string, number>; issues: { category: string; message: string }[]; disclaimer: string }
export type Match = { coverage: number; matched_keywords: string[]; missing_keywords: string[]; suggestions: string[] }
